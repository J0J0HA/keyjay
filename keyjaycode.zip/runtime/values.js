"use strict";
exports.__esModule = true;
exports.MK_RET = exports.MK_LIST = exports.MK_OBJ = exports.MK_TYPE = exports.MK_STRING = exports.MK_NUMBER = exports.MK_BOOL = exports.MK_NONE = void 0;
function MK_NONE() {
    return { type: "none", value: null };
}
exports.MK_NONE = MK_NONE;
function MK_BOOL(b) {
    if (b === void 0) { b = true; }
    return { type: "boolean", value: b };
}
exports.MK_BOOL = MK_BOOL;
function MK_NUMBER(n) {
    if (n === void 0) { n = 0; }
    return { type: "number", value: n };
}
exports.MK_NUMBER = MK_NUMBER;
function MK_STRING(s) {
    if (s === void 0) { s = ""; }
    return { type: "string", value: s };
}
exports.MK_STRING = MK_STRING;
function MK_TYPE(t) {
    if (t === void 0) { t = "null"; }
    return { type: "type", value: t };
}
exports.MK_TYPE = MK_TYPE;
function MK_OBJ(o) {
    if (o === void 0) { o = {}; }
    var value = new Map();
    for (var key in o) {
        value.set(key, o[key]);
    }
    return { type: "object", value: value };
}
exports.MK_OBJ = MK_OBJ;
function MK_LIST(l) {
    if (l === void 0) { l = []; }
    return { type: "list", value: l };
}
exports.MK_LIST = MK_LIST;
function MK_RET(v) {
    if (v === void 0) { v = MK_NONE(); }
    return { type: "@internal:return", value: v };
}
exports.MK_RET = MK_RET;
