"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
exports.__esModule = true;
exports.types = void 0;
var i = require("./values");
function gtype(name) {
    return exports.types[name] || basics;
}
exports["default"] = gtype;
var basics = {
    "type": {
        type: "nativecode",
        value: function (self) {
            return i.MK_TYPE(self.type);
        }
    },
    "asNum": {
        type: "nativecode",
        value: function (self) {
            throw "Type ".concat(self.type, " has no function provided to handle .asNum()");
        }
    },
    "asStr": {
        type: "nativecode",
        value: function (self) {
            return gtype(self.type).repr.value(self);
        }
    },
    "asBool": {
        type: "nativecode",
        value: function (self) {
            throw "Type ".concat(self.type, " has no function provided to handle .asBool()");
        }
    },
    "repr": {
        type: "nativecode",
        value: function (self) {
            return i.MK_STRING("<unknown type ".concat(self.type, ">"));
        }
    },
    "measure": {
        type: "nativecode",
        value: function (self) {
            throw "Type ".concat(self.type, " has no function provided to handle .measure()");
        }
    }
};
exports.types = {
    "none": __assign(__assign({}, basics), { "asStr": {
            type: "nativecode",
            value: function (self) {
                return i.MK_STRING("none");
            }
        }, "asNum": {
            type: "nativecode",
            value: function (self) {
                return i.MK_NUMBER(0);
            }
        }, "asBool": {
            type: "nativecode",
            value: function (self) {
                return i.MK_BOOL(false);
            }
        }, "repr": {
            type: "nativecode",
            value: function (self) {
                return i.MK_STRING("none");
            }
        } }),
    "boolean": __assign(__assign({}, basics), { "asStr": {
            type: "nativecode",
            value: function (self) {
                return i.MK_STRING(self.value ? "true" : "false");
            }
        }, "asNum": {
            type: "nativecode",
            value: function (self) {
                return i.MK_NUMBER(self.value ? 0 : 1);
            }
        }, "asBool": {
            type: "nativecode",
            value: function (self) {
                return i.MK_BOOL(self.value);
            }
        }, "repr": {
            type: "nativecode",
            value: function (self) {
                return i.MK_STRING("".concat(self.value ? "true" : "false"));
            }
        } }),
    "number": __assign(__assign({}, basics), { "asStr": {
            type: "nativecode",
            value: function (self) {
                return i.MK_STRING(self.value);
            }
        }, "asNum": {
            type: "nativecode",
            value: function (self) {
                return self;
            }
        }, "asBool": {
            type: "nativecode",
            value: function (self) {
                return i.MK_BOOL((self.value != 0) ? true : false);
            }
        }, "repr": {
            type: "nativecode",
            value: function (self) {
                return i.MK_STRING("".concat(self.value));
            }
        }, "measure": {
            type: "nativecode",
            value: function (self) {
                return i.MK_NUMBER(self.value);
            }
        } }),
    "string": __assign(__assign({}, basics), { "asNum": {
            type: "nativecode",
            value: function (self) {
                return i.MK_NUMBER(parseInt(self.value));
            }
        }, "asStr": {
            type: "nativecode",
            value: function (self) {
                return self;
            }
        }, "asBool": {
            type: "nativecode",
            value: function (self) {
                return i.MK_BOOL((self.value == "") ? true : false);
            }
        }, "repr": {
            type: "nativecode",
            value: function (self) {
                return i.MK_STRING("\"".concat(self.value, "\""));
            }
        }, "measure": {
            type: "nativecode",
            value: function (self) {
                return i.MK_NUMBER(self.value.length);
            }
        } }),
    "object": __assign(__assign({}, basics), { "asJson": {
            type: "nativecode",
            value: function (self) {
                var props = [];
                for (var _i = 0, _a = self.value; _i < _a.length; _i++) {
                    var prop = _a[_i];
                    var val = gtype(prop[1].type).repr.value(prop[1]).value;
                    props.push("\"" + prop[0] + "\": " + (val || "null"));
                }
                return i.MK_STRING("{".concat(props.join(', '), "}"));
            }
        }, "repr": {
            type: "nativecode",
            value: function (self) {
                var props = [];
                for (var _i = 0, _a = Array.from(self.value.entries()); _i < _a.length; _i++) {
                    var prop = _a[_i];
                    // @ts-ignore
                    props.push(prop[0] + ": " + gtype(prop[1].type).repr.value(prop[1]).value);
                }
                return i.MK_STRING("{".concat(props.join(', '), "}"));
            }
        }, "measure": {
            type: "nativecode",
            value: function (self) {
                return i.MK_NUMBER(self.value.length);
            }
        } }),
    "list": __assign(__assign({}, basics), { "repr": {
            type: "nativecode",
            value: function (self) {
                var props = [];
                for (var _i = 0, _a = self.value; _i < _a.length; _i++) {
                    var item = _a[_i];
                    props.push(gtype(item.type).repr.value(item).value);
                }
                return i.MK_STRING("[".concat(props.join(', '), "]"));
            }
        }, "measure": {
            type: "nativecode",
            value: function (self) {
                return i.MK_NUMBER(self.value.length);
            }
        } }),
    "function": __assign(__assign({}, basics), { "repr": {
            type: "nativecode",
            value: function (self) {
                return i.MK_STRING("<function>");
            }
        } }),
    "nativecode": __assign(__assign({}, basics), { "repr": {
            type: "nativecode",
            value: function (self) {
                return i.MK_STRING("<native code>");
            }
        } })
};
