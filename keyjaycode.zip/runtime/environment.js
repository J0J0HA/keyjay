"use strict";
exports.__esModule = true;
exports.createGlobalEnv = void 0;
var types_1 = require("./types");
var types_2 = require("./types");
var interpreter_1 = require("./interpreter");
var parser_1 = require("../frontend/parser");
var values_1 = require("./values");
var prompt = require("readline-sync").question;
var fs = require("fs");
function createGlobalEnv(path) {
    var env = new Environment();
    // Create Default Global Enviornment
    env.declareVar("system", (0, values_1.MK_OBJ)({
        impl: (0, values_1.MK_STRING)("TypeScript"),
        name: (0, values_1.MK_STRING)("KeyJay"),
        version: (0, values_1.MK_STRING)("v0.1"),
        path: (0, values_1.MK_STRING)(path)
    }), true);
    env.declareVar("print", {
        type: "nativecode",
        value: function (arg) {
            var _a, _b, _c, _d, _e, _f, _g, _h;
            console.log(((_d = (_c = (_b = (_a = types_2.types[arg.type]) === null || _a === void 0 ? void 0 : _a.asStr) === null || _b === void 0 ? void 0 : _b.value) === null || _c === void 0 ? void 0 : _c.call(_b, arg)) === null || _d === void 0 ? void 0 : _d.value) || ((_h = (_g = (_f = (_e = types_2.types[arg.type]) === null || _e === void 0 ? void 0 : _e.repr) === null || _f === void 0 ? void 0 : _f.value) === null || _g === void 0 ? void 0 : _g.call(_f, arg)) === null || _h === void 0 ? void 0 : _h.value) || "<unknown type ".concat(arg.type, ">"));
            return (0, values_1.MK_NONE)();
        }
    }, true);
    env.declareVar("import", {
        type: "nativecode",
        env: true,
        value: function (env, arg) {
            var subenv = new Environment(env);
            subenv.declareVar("system", (0, values_1.MK_OBJ)({
                impl: (0, values_1.MK_STRING)("TypeScript"),
                name: (0, values_1.MK_STRING)("KeyJay"),
                version: (0, values_1.MK_STRING)("v0.1"),
                path: (0, values_1.MK_STRING)(arg.value)
            }), true);
            var code = fs.readFileSync(arg.value);
            var parser = new parser_1["default"]();
            var prog = parser.produceAST(code);
            (0, interpreter_1.evaluate)(prog, subenv);
            var obj = {};
            subenv.variables.forEach(function () {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                obj[args[1]] = args[0];
            });
            return (0, values_1.MK_OBJ)(obj);
        }
    }, true);
    env.declareVar("eval", {
        type: "nativecode",
        value: function (arg) {
            var env = createGlobalEnv("<eval>");
            var parser = new parser_1["default"]();
            var prog = parser.produceAST(arg.value);
            return (0, interpreter_1.evaluate)(prog, env);
        }
    }, true);
    env.declareVar("range", {
        type: "nativecode",
        value: function (kjmin, kjmax) {
            var kjlist = [];
            if (!kjmax) {
                kjmax = kjmin.value;
                kjmin = (0, values_1.MK_NUMBER)(0);
            }
            if (!((kjmin === null || kjmin === void 0 ? void 0 : kjmin.type) == "number" && (kjmax === null || kjmax === void 0 ? void 0 : kjmax.type) == "number")) {
                throw "Invalid types ".concat(kjmin.type, " and ").concat(kjmax.type, " to get range. both must be number.");
            }
            var nmin = kjmin.value;
            var nmax = kjmax.value;
            for (var x = nmin; x < nmin + nmax; x += 1) {
                kjlist.push((0, values_1.MK_NUMBER)(x));
            }
            return (0, values_1.MK_LIST)(kjlist);
        }
    }, true);
    env.declareVar("input", {
        type: "nativecode",
        value: function (arg) {
            var ret = prompt((0, types_1["default"])(arg.type || "none").asStr.value(arg).value);
            if (!ret) {
                return (0, values_1.MK_NONE)();
            }
            else {
                return (0, values_1.MK_STRING)(ret);
            }
        }
    }, true);
    env.declareVar("type", (0, values_1.MK_OBJ)({
        "function": (0, values_1.MK_TYPE)("function"),
        nativecode: (0, values_1.MK_TYPE)("nativecode"),
        boolean: (0, values_1.MK_TYPE)("boolean"),
        number: (0, values_1.MK_TYPE)("number"),
        string: (0, values_1.MK_TYPE)("string"),
        object: (0, values_1.MK_TYPE)("object"),
        type: (0, values_1.MK_TYPE)("type"),
        none: (0, values_1.MK_TYPE)("none")
    }), true);
    env.declareVar("true", (0, values_1.MK_BOOL)(true), true);
    env.declareVar("false", (0, values_1.MK_BOOL)(false), true);
    env.declareVar("none", (0, values_1.MK_NONE)(), true);
    return env;
}
exports.createGlobalEnv = createGlobalEnv;
var Environment = /** @class */ (function () {
    function Environment(parentENV) {
        var global = parentENV ? true : false;
        this.parent = parentENV;
        this.variables = new Map();
        this.constants = new Set();
    }
    Environment.prototype.declareVar = function (varname, value, constant) {
        if (this.variables.has(varname)) {
            throw "Cannot declare variable ".concat(varname, ". As it already is defined.");
        }
        this.variables.set(varname, value);
        if (constant) {
            this.constants.add(varname);
        }
        return value;
    };
    Environment.prototype.assignVar = function (varname, value, ignoreconst) {
        if (ignoreconst === void 0) { ignoreconst = false; }
        var env = this.resolve(varname);
        // Cannot assign to constant
        if (env.constants.has(varname) && !ignoreconst) {
            throw "Cannot reasign to variable ".concat(varname, " as it was declared constant.");
        }
        env.variables.set(varname, value);
        return value;
    };
    Environment.prototype.lookupVar = function (varname) {
        var env = this.resolve(varname);
        return env.variables.get(varname);
    };
    Environment.prototype.resolve = function (varname) {
        if (this.variables.has(varname)) {
            return this;
        }
        if (this.parent == undefined) {
            throw "Cannot resolve '".concat(varname, "' as it does not exist.");
        }
        return this.parent.resolve(varname);
    };
    return Environment;
}());
exports["default"] = Environment;
