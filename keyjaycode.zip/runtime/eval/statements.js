"use strict";
exports.__esModule = true;
exports.eval_for_loop = exports.eval_while_loop = exports.eval_if = exports.eval_function_declaration = exports.eval_var_declaration = exports.eval_program = void 0;
var environment_1 = require("../environment");
var interpreter_1 = require("../interpreter");
var values_1 = require("../values");
var expressions_1 = require("./expressions");
var types_1 = require("../types");
function eval_program(program, env) {
    var lastEvaluated = (0, values_1.MK_NONE)();
    for (var _i = 0, _a = program.body; _i < _a.length; _i++) {
        var statement = _a[_i];
        lastEvaluated = (0, interpreter_1.evaluate)(statement, env);
        if (lastEvaluated.type == "@internal:return") {
            console.log("\nProcess ended with:", lastEvaluated.value.value || 0);
            // @ts-ignore
            Deno.exit(lastEvaluated.value.value);
        }
    }
    return lastEvaluated;
}
exports.eval_program = eval_program;
function eval_var_declaration(declaration, env) {
    var value = declaration.value
        ? (0, interpreter_1.evaluate)(declaration.value, env)
        : (0, values_1.MK_NONE)();
    return env.declareVar(declaration.identifier, value, declaration.constant);
}
exports.eval_var_declaration = eval_var_declaration;
function eval_function_declaration(funcdecl, env) {
    env.declareVar(funcdecl.identifier, { type: "function", args: funcdecl.args, body: funcdecl.code }, false);
    return env.lookupVar(funcdecl.identifier);
}
exports.eval_function_declaration = eval_function_declaration;
function eval_if(ifstmt, env) {
    var ifstmtenv = new environment_1["default"](env);
    var selfif = (0, interpreter_1.evaluate)(ifstmt.expr, env);
    if ((0, expressions_1.run_func)((0, types_1["default"])(selfif.type).toBoolean, [], {}, env, selfif.value)) {
        for (var _i = 0, _a = ifstmt.body; _i < _a.length; _i++) {
            var stmt = _a[_i];
            if (stmt.kind == "ContinueStmt") {
                return (0, values_1.MK_NONE)();
            }
            if (stmt.kind == "BreakStmt") {
                return (0, values_1.MK_NONE)();
            }
            if (stmt.kind == "ReturnStmt") {
                return (0, values_1.MK_RET)((0, interpreter_1.evaluate)(stmt.expr, ifstmtenv));
            }
            (0, interpreter_1.evaluate)(stmt, ifstmtenv);
        }
    }
    return (0, values_1.MK_NONE)();
}
exports.eval_if = eval_if;
function eval_while_loop(loop, env) {
    var loopenv = new environment_1["default"](env);
    outer: while ((0, expressions_1.run_func)((0, types_1["default"])((0, interpreter_1.evaluate)(loop.expr, env).type).toBoolean, [], {}, env, (0, interpreter_1.evaluate)(loop.expr, env)).value) {
        for (var _i = 0, _a = loop.body; _i < _a.length; _i++) {
            var stmt = _a[_i];
            if (stmt.kind == "ContinueStmt") {
                continue outer;
            }
            if (stmt.kind == "BreakStmt") {
                return (0, values_1.MK_NONE)();
            }
            if (stmt.kind == "ReturnStmt") {
                return (0, values_1.MK_RET)((0, interpreter_1.evaluate)(stmt.expr, loopenv));
            }
            (0, interpreter_1.evaluate)(stmt, loopenv);
        }
    }
    return (0, values_1.MK_NONE)();
}
exports.eval_while_loop = eval_while_loop;
function eval_for_loop(loop, env) {
    var loopenv = new environment_1["default"](env);
    if (loop.operator.value == "in" && loop.expr) { // last only for making it compile
        loopenv.declareVar(loop.identifier.value, (0, values_1.MK_NONE)(), false);
        outer: for (var x_1 in (0, interpreter_1.evaluate)(loop.expr, env).value) {
            loopenv.assignVar(loop.identifier.value, (0, values_1.MK_NUMBER)(parseInt(x_1)), true);
            for (var _i = 0, _a = loop.body; _i < _a.length; _i++) {
                var stmt = _a[_i];
                if (stmt.kind == "ContinueStmt") {
                    continue outer;
                }
                if (stmt.kind == "BreakStmt") {
                    return (0, values_1.MK_NONE)();
                }
                if (stmt.kind == "ReturnStmt") {
                    return (0, values_1.MK_RET)((0, interpreter_1.evaluate)(stmt.expr, loopenv));
                }
                (0, interpreter_1.evaluate)(stmt, loopenv);
            }
        }
    }
    else if (loop.operator.value == "times") {
        outer: for (var x = 0; x < parseInt(loop.identifier.value); x += 1) {
            for (var _b = 0, _c = loop.body; _b < _c.length; _b++) {
                var stmt = _c[_b];
                if (stmt.kind == "ContinueStmt") {
                    continue outer;
                }
                if (stmt.kind == "BreakStmt") {
                    return (0, values_1.MK_NONE)();
                }
                if (stmt.kind == "ReturnStmt") {
                    return (0, values_1.MK_RET)((0, interpreter_1.evaluate)(stmt.expr, loopenv));
                }
                (0, interpreter_1.evaluate)(stmt, loopenv);
            }
        }
    }
    else {
        throw "Unknown for-Loop operator for interpreter";
    }
    return (0, values_1.MK_NONE)();
}
exports.eval_for_loop = eval_for_loop;
