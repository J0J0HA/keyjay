"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
exports.__esModule = true;
exports.eval_member_expr = exports.eval_list_expr = exports.eval_object_expr = exports.eval_assignment = exports.eval_call_expr = exports.run_func = exports.eval_identifier = exports.eval_logical_expr = exports.eval_comparison_expr = exports.eval_unary_expr = exports.eval_binary_expr = void 0;
var environment_1 = require("../environment");
var interpreter_1 = require("../interpreter");
var values_1 = require("../values");
var types_1 = require("../types");
var types_2 = require("../types");
function eval_numnum_binary_expr(lhs, rhs, operator) {
    var result;
    if (operator == "+") {
        result = lhs.value + rhs.value;
    }
    else if (operator == "-") {
        result = lhs.value - rhs.value;
    }
    else if (operator == "*") {
        result = lhs.value * rhs.value;
    }
    else if (operator == "/") {
        // TODO: Division by zero checks
        result = lhs.value / rhs.value;
    }
    else if (operator == "/") {
        result = lhs.value % rhs.value;
    }
    else {
        throw "type number does not support operator ".concat(operator, " with type number");
    }
    return { value: result, type: "number" };
}
function eval_strstr_binary_expr(lhs, rhs, operator) {
    var result;
    if (operator == "+") {
        result = lhs.value + rhs.value;
    }
    else {
        throw "type string does not support operator ".concat(operator, " with type string");
    }
    return { value: result, type: "string" };
}
function eval_strnum_binary_expr(lhs, rhs, operator) {
    var result;
    if (operator == "+") {
        result = lhs.value + rhs.value;
    }
    else if (operator == "*") {
        result = lhs.value.repeat(rhs.value);
    }
    else {
        throw "type string does not support operator ".concat(operator, " with type number");
    }
    return { value: result, type: "string" };
}
/**
 * Evaulates expressions following the binary operation type.
 */
function eval_binary_expr(binop, env) {
    var lhs = (0, interpreter_1.evaluate)(binop.left, env);
    var rhs = (0, interpreter_1.evaluate)(binop.right, env);
    // Only currently support numeric operations
    if (lhs.type == "number" && rhs.type == "number") {
        return eval_numnum_binary_expr(lhs, rhs, binop.operator);
    }
    else if (lhs.type == "string" && rhs.type == "string") {
        return eval_strstr_binary_expr(lhs, rhs, binop.operator);
    }
    else if (lhs.type == "string" && rhs.type == "number") {
        return eval_strnum_binary_expr(lhs, rhs, binop.operator);
    }
    else {
        throw "type ".concat(lhs.type, " does not support binary operators with type ").concat(rhs.type);
    }
}
exports.eval_binary_expr = eval_binary_expr;
function eval_unary_expr(unop, env) {
    var expr = (0, interpreter_1.evaluate)(unop.expr, env);
    if (unop.operator == "!") {
        var type = (0, types_1["default"])(expr.type);
        return (0, values_1.MK_BOOL)(!type.asBool.value(expr).value);
    }
    else {
        throw "type ".concat(expr.type, " could not handle unary operator ").concat(unop.operator);
    }
}
exports.eval_unary_expr = eval_unary_expr;
function eval_comparison_expr(comparison, env) {
    var result;
    var lhsr = (0, interpreter_1.evaluate)(comparison.left, env);
    var rhsr = (0, interpreter_1.evaluate)(comparison.right, env);
    if (comparison.operator == "==") {
        result = (lhsr.type == rhsr.type && lhsr.value == rhsr.value);
    }
    else if (comparison.operator == "!=") {
        result = (lhsr.type != rhsr.type || lhsr.value != rhsr.value);
    }
    else if (comparison.operator == ">=") {
        var lhs = (0, types_1["default"])(lhsr.type).measure.value(lhsr);
        var rhs = (0, types_1["default"])(rhsr.type).measure.value(rhsr);
        result = (lhs.value >= rhs.value); // only nums later !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    }
    else if (comparison.operator == "<=") {
        var lhs = (0, types_1["default"])(lhsr.type).measure.value(lhsr);
        var rhs = (0, types_1["default"])(rhsr.type).measure.value(rhsr);
        result = (lhs.value <= rhs.value);
    }
    else if (comparison.operator == ">") {
        var lhs = (0, types_1["default"])(lhsr.type).measure.value(lhsr);
        var rhs = (0, types_1["default"])(rhsr.type).measure.value(rhsr);
        result = (lhs.value > rhs.value); // only nums later !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    }
    else if (comparison.operator == "<") {
        var lhs = (0, types_1["default"])(lhsr.type).measure.value(lhsr);
        var rhs = (0, types_1["default"])(rhsr.type).measure.value(rhsr);
        result = (lhs.value < rhs.value);
    }
    else {
        throw "comparison operator ".concat(comparison.operator, " is not allowed.");
    }
    return { value: result, type: "boolean" };
}
exports.eval_comparison_expr = eval_comparison_expr;
function eval_logical_expr(logic, env) {
    var result;
    var lhsr = (0, interpreter_1.evaluate)(logic.left, env);
    var rhsr = (0, interpreter_1.evaluate)(logic.right, env);
    var lhs = (0, types_1["default"])(lhsr.type).asBool.value(lhsr);
    var rhs = (0, types_1["default"])(rhsr.type).asBool.value(rhsr);
    if (logic.operator == "&") {
        result = (lhs.value && rhs.value);
    }
    else if (logic.operator == "|") {
        result = (lhs.value || rhs.value);
    }
    else if (logic.operator == "!|") {
        result = (lhs.value != rhs.value);
    }
    else {
        throw "comparison operator ".concat(logic.operator, " is not allowed.");
    }
    return { value: result, type: "boolean" };
}
exports.eval_logical_expr = eval_logical_expr;
function eval_identifier(ident, env) {
    var val = env.lookupVar(ident.symbol);
    return val;
}
exports.eval_identifier = eval_identifier;
function run_func(func, args, kwargs, env, self) {
    if (func.type == "function") {
        var funcenv = new environment_1["default"](env);
        if (self) {
            funcenv.declareVar("self", self, false);
        }
        for (var arg in func.args) {
            funcenv.declareVar(func.args[arg].identifier, (0, interpreter_1.evaluate)(kwargs[func.args[arg].identifier] || args[arg] || func.args[arg].value, env), false);
        }
        for (var _i = 0, _a = func.body; _i < _a.length; _i++) {
            var stmt = _a[_i];
            if (stmt.kind == "ReturnStmt") {
                return (0, interpreter_1.evaluate)(stmt.expr, funcenv);
            }
            (0, interpreter_1.evaluate)(stmt, funcenv);
        }
        return (0, values_1.MK_NONE)();
    }
    if (func.type == "nativecode") {
        var newargs = [];
        var newkwargs = {};
        if (func.env) {
            newargs.push(env);
        }
        for (var arg in args) {
            newargs.push((0, interpreter_1.evaluate)(args[arg], env));
        }
        for (var arg in kwargs) {
            newkwargs[arg] = (0, interpreter_1.evaluate)(kwargs[arg], env);
        }
        if (self) {
            return func.value.apply(func, __spreadArray(__spreadArray([self], newargs, false), [newkwargs], false));
        }
        else {
            return func.value.apply(func, __spreadArray(__spreadArray([], newargs, false), [newkwargs], false));
        }
    }
    // @ts-ignore
    throw "Type ".concat((func === null || func === void 0 ? void 0 : func.type) || "<unknown>", " does not support function calls.");
}
exports.run_func = run_func;
function eval_call_expr(call, env) {
    var _a;
    var func = (0, interpreter_1.evaluate)(call.caller, env);
    // @ts-ignore
    return run_func(func, call.args, call.kwargs, env, call.caller.object ? (0, interpreter_1.evaluate)((_a = call.caller) === null || _a === void 0 ? void 0 : _a.object, env) : null);
}
exports.eval_call_expr = eval_call_expr;
function eval_assignment(node, env) {
    if (node.assigne.kind !== "Identifier") {
        console.error("Invalid LHS inaide assignment expr ".concat(JSON.stringify(node.assigne)));
        throw "Invalid LHS inaide assignment expr";
    }
    var varname = node.assigne.symbol;
    return env.assignVar(varname, (0, interpreter_1.evaluate)(node.value, env));
}
exports.eval_assignment = eval_assignment;
function eval_object_expr(obj, env) {
    var object = { type: "object", value: new Map() };
    for (var _i = 0, _a = obj.value; _i < _a.length; _i++) {
        var _b = _a[_i], key = _b.key, value = _b.value;
        var runtimeVal = (value == undefined)
            ? env.lookupVar(key)
            : (0, interpreter_1.evaluate)(value, env);
        object.value.set(key, runtimeVal);
    }
    return object;
}
exports.eval_object_expr = eval_object_expr;
function eval_list_expr(list, env) {
    var kjlist = { type: "list", value: [] };
    for (var _i = 0, _a = list.value; _i < _a.length; _i++) {
        var value = _a[_i];
        kjlist.value.push((0, interpreter_1.evaluate)(value, env));
    }
    return kjlist;
}
exports.eval_list_expr = eval_list_expr;
function eval_member_expr(expr, env) {
    var _a, _b, _c, _d;
    var org = (0, interpreter_1.evaluate)(expr.object, env);
    var prop = expr.computed ? (0, interpreter_1.evaluate)(expr.property, env).value : expr.property.symbol;
    if ((!expr.computed) && ((_a = types_2.types[org.type]) === null || _a === void 0 ? void 0 : _a[prop])) {
        return (0, types_1["default"])(org.type)[prop];
    }
    else if ((_b = org.value) === null || _b === void 0 ? void 0 : _b.has(prop)) {
        return org.value.get(prop);
    }
    else if (expr.computed && ((_c = org.value) === null || _c === void 0 ? void 0 : _c[prop])) {
        return (_d = org.value) === null || _d === void 0 ? void 0 : _d[prop];
    }
    else {
        console.error("No such property '".concat(prop, "'"));
        throw "No such property";
    }
}
exports.eval_member_expr = eval_member_expr;
