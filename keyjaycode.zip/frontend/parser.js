"use strict";
exports.__esModule = true;
var lexer_1 = require("./lexer");
/**
 * Frontend for producing a valid AST from sourcode
 */
var Parser = /** @class */ (function () {
    function Parser() {
        this.tokens = [];
    }
    /*
     * Determines if the parsing is complete and the END OF FILE Is reached.
     */
    Parser.prototype.not_eof = function () {
        return this.tokens[0].type != lexer_1.TokenType.EOF;
    };
    /**
     * Returns the currently available token
     */
    Parser.prototype.at = function () {
        return this.tokens[0];
    };
    /**
     * Returns the previous token and then advances the tokens array to the next value.
     */
    Parser.prototype.eat = function () {
        var prev = this.tokens.shift();
        return prev;
    };
    /**
     * Returns the previous token and then advances the tokens array to the next value.
     *  Also checks the type of expected token and throws if the values dnot match.
     */
    Parser.prototype.expect = function (type, want, err) {
        var prev = this.tokens.shift();
        if (!prev || prev.type != type) {
            // @ts-ignore
            throw "Parser Error: Got ".concat(prev.value, " (").concat(prev.type, "), expected ").concat(want, " (").concat(type, ") ").concat(err || "");
        }
        return prev;
    };
    Parser.prototype.produceAST = function (sourceCode) {
        this.tokens = (0, lexer_1.tokenize)(sourceCode);
        var program = {
            kind: "Program",
            body: []
        };
        // Parse until end of file
        while (this.not_eof()) {
            program.body.push(this.parse_stmt());
        }
        return program;
    };
    // Handle complex statement types
    Parser.prototype.parse_stmt = function () {
        // skip to parse_expr
        switch (this.at().type) {
            case lexer_1.TokenType.Var:
            case lexer_1.TokenType.Const:
                return this.parse_var_declaration();
            case lexer_1.TokenType.Func:
                return this.parse_func_declaration();
            case lexer_1.TokenType.While:
                return this.parse_while_loop();
            case lexer_1.TokenType.For:
                return this.parse_for_loop();
            case lexer_1.TokenType.If:
                return this.parse_if();
            case lexer_1.TokenType.Return:
                return this.parse_return();
            case lexer_1.TokenType.Continue:
                return this.parse_continue();
            case lexer_1.TokenType.Break:
                return this.parse_break();
            default:
                return this.parse_expr();
        }
    };
    Parser.prototype.parse_for_loop = function () {
        this.eat();
        var identifier = this.eat();
        var operator = this.eat();
        if (operator.type == lexer_1.TokenType.In) {
            var expr = this.parse_expr();
            this.expect(lexer_1.TokenType.OpenBrace, "{", "after for expr");
            var body = [];
            while (this.not_eof() && this.at().value != "}") {
                body.push(this.parse_stmt());
            }
            this.expect(lexer_1.TokenType.CloseBrace, "}", "after while body");
            return { kind: "ForLoop", identifier: identifier, operator: operator, expr: expr, body: body };
        }
        else if (operator.type == lexer_1.TokenType.Times) {
            this.expect(lexer_1.TokenType.OpenBrace, "{", "after for-expr");
            var body = [];
            while (this.not_eof() && this.at().value != "}") {
                body.push(this.parse_stmt());
            }
            this.expect(lexer_1.TokenType.CloseBrace, "}", "after for-expr");
            return { kind: "ForLoop", identifier: identifier, operator: operator, body: body };
        }
        throw "Expected in or times keyword after for keyword.";
    };
    Parser.prototype.parse_while_loop = function () {
        this.eat();
        var expr = this.parse_expr();
        this.expect(lexer_1.TokenType.OpenBrace, "{", "after while condition");
        var body = [];
        while (this.not_eof() && this.at().value != "}") {
            body.push(this.parse_stmt());
        }
        this.expect(lexer_1.TokenType.CloseBrace, "}", "after while body");
        return { kind: "WhileLoop", expr: expr, body: body };
    };
    Parser.prototype.parse_if = function () {
        this.eat();
        var expr = this.parse_expr();
        this.expect(lexer_1.TokenType.OpenBrace, "{", "after if condition");
        var body = [];
        while (this.not_eof() && this.at().value != "}") {
            body.push(this.parse_stmt());
        }
        this.expect(lexer_1.TokenType.CloseBrace, "}", "after if body");
        return { kind: "IfStmt", expr: expr, body: body };
    };
    // VAR IDENT;
    // ( VAR | CONST ) IDENT = EXPR;
    Parser.prototype.parse_var_declaration = function () {
        var isConstant = this.eat().type == lexer_1.TokenType.Const;
        var identifier = this.expect(lexer_1.TokenType.Identifier, "identifier name", "following var or const keyword").value;
        if (this.at().type == lexer_1.TokenType.Semicolon) {
            this.eat(); // expect semicolon
            if (isConstant) {
                throw "Parser Error: Expected Expression, got ;";
            }
            return {
                kind: "VarDeclaration",
                identifier: identifier,
                constant: false
            };
        }
        this.expect(lexer_1.TokenType.Equals, "=", "following identifier in var declaration");
        var declaration = {
            kind: "VarDeclaration",
            value: this.parse_expr(),
            identifier: identifier,
            constant: isConstant
        };
        this.expect(lexer_1.TokenType.Semicolon, ";", "at the end of variable declaration");
        return declaration;
    };
    Parser.prototype.parse_func_declaration = function () {
        this.eat();
        var identifier = this.expect(lexer_1.TokenType.Identifier, "identifier name", "following func keyword").value;
        var args = this.parse_declaration_args();
        this.expect(lexer_1.TokenType.OpenBrace, "{", "following function args in declaration").value;
        var declaration = {
            kind: "FuncDeclaration",
            args: args,
            code: [],
            identifier: identifier
        };
        while (this.not_eof() && this.at().value != "}") {
            declaration.code.push(this.parse_stmt());
        }
        this.expect(lexer_1.TokenType.CloseBrace, "}", "after function body");
        return declaration;
    };
    Parser.prototype.parse_continue = function () {
        this.eat();
        var ret = {
            kind: "ContinueStmt"
        };
        this.expect(lexer_1.TokenType.Semicolon, "Continue must end with semicolon.");
        return ret;
    };
    Parser.prototype.parse_break = function () {
        this.eat();
        var ret = {
            kind: "BreakStmt"
        };
        this.expect(lexer_1.TokenType.Semicolon, ";", "after break keyword");
        return ret;
    };
    Parser.prototype.parse_return = function () {
        this.eat();
        var ret = {
            kind: "ReturnStmt",
            expr: this.parse_expr()
        };
        this.expect(lexer_1.TokenType.Semicolon, ";", "after return keyword");
        return ret;
    };
    // Handle expressions
    Parser.prototype.parse_expr = function () {
        return this.parse_assignment_expr();
    };
    Parser.prototype.parse_assignment_expr = function () {
        var left = this.parse_logical_expr();
        if (this.at().type == lexer_1.TokenType.Equals) {
            this.eat(); // advance past equals
            var value = this.parse_expr();
            return { value: value, assigne: left, kind: "AssignmentExpr" };
        }
        return left;
    };
    Parser.prototype.parse_logical_expr = function () {
        var left = this.parse_comparison_expr();
        while (this.at().type == lexer_1.TokenType.LogicalOperator) {
            var operator = this.eat().value;
            var right = this.parse_comparison_expr();
            left = {
                kind: "LogicalExpr",
                left: left,
                right: right,
                operator: operator
            };
        }
        return left;
    };
    Parser.prototype.parse_comparison_expr = function () {
        var left = this.parse_object_expr();
        while (this.at().type == lexer_1.TokenType.ComparisonOperator) {
            var operator = this.eat().value;
            var right = this.parse_object_expr();
            left = {
                kind: "ComparisonExpr",
                left: left,
                right: right,
                operator: operator
            };
        }
        return left;
    };
    Parser.prototype.parse_object_expr = function () {
        // { Prop[] }
        if (this.at().type !== lexer_1.TokenType.OpenBrace) {
            return this.parse_list_expr();
        }
        this.eat(); // advance past open brace.
        var value = new Array();
        while (this.not_eof() && this.at().type != lexer_1.TokenType.CloseBrace) {
            var key = this.expect(lexer_1.TokenType.Identifier, "Object literal key exprected").value;
            // Allows shorthand key: pair -> { key, }
            if (this.at().type == lexer_1.TokenType.Comma) {
                this.eat(); // advance past comma
                value.push({ key: key, kind: "Property" });
                continue;
            } // Allows shorthand key: pair -> { key }
            else if (this.at().type == lexer_1.TokenType.CloseBrace) {
                value.push({ key: key, kind: "Property" });
                continue;
            }
            // { key: val }
            this.expect(lexer_1.TokenType.Colon, ":", "following identifier in object expr");
            var actvalue = this.parse_expr();
            value.push({ kind: "Property", value: actvalue, key: key });
            if (this.at().type != lexer_1.TokenType.CloseBrace) {
                this.expect(lexer_1.TokenType.Comma, ", or }", "following property");
            }
        }
        this.expect(lexer_1.TokenType.CloseBrace, "}", "after object literal");
        return { kind: "ObjectLiteral", value: value };
    };
    Parser.prototype.parse_list_expr = function () {
        // { Prop[] }
        if (this.at().type !== lexer_1.TokenType.OpenBracket) {
            return this.parse_additive_expr();
        }
        this.eat(); // advance past open brace.
        var value = new Array();
        while (this.not_eof() && this.at().type != lexer_1.TokenType.CloseBracket) {
            value.push(this.parse_expr());
            if (this.at().type == lexer_1.TokenType.Comma) {
                this.eat();
            }
        }
        this.expect(lexer_1.TokenType.CloseBracket, "]", "after list literal");
        return { kind: "ListLiteral", value: value };
    };
    // Handle Addition & Subtraction Operations
    Parser.prototype.parse_additive_expr = function () {
        var left = this.parse_multiplicitave_expr();
        while (this.at().value == "+" || this.at().value == "-") {
            var operator = this.eat().value;
            var right = this.parse_expr();
            left = {
                kind: "BinaryExpr",
                left: left,
                right: right,
                operator: operator
            };
        }
        return left;
    };
    // Handle Multiplication, Division & Modulo Operations
    Parser.prototype.parse_multiplicitave_expr = function () {
        var left = this.parse_call_member_expr();
        while (this.at().value == "/" || this.at().value == "*" || this.at().value == "%") {
            var operator = this.eat().value;
            var right = this.parse_call_member_expr();
            left = {
                kind: "BinaryExpr",
                left: left,
                right: right,
                operator: operator
            };
        }
        return left;
    };
    // foo.x()()
    // foo.buzz().bar()
    Parser.prototype.parse_call_member_expr = function () {
        var member = this.parse_member_expr();
        if (this.at().type == lexer_1.TokenType.OpenParen && !this.at().differ) {
            return this.parse_call_expr(member);
        }
        return member;
    };
    Parser.prototype.parse_call_expr = function (caller) {
        var args = this.parse_args();
        var call_expr = {
            kind: "CallExpr",
            caller: caller,
            args: args[0],
            kwargs: args[1]
        };
        if (this.at().type == lexer_1.TokenType.OpenParen && !this.at().differ) {
            call_expr = this.parse_call_expr(call_expr);
        }
        if (this.at().type == lexer_1.TokenType.Dot && !this.at().differ) {
            this.eat();
            var member = this.parse_member_expr();
            if (this.at().type == lexer_1.TokenType.OpenParen && !this.at().differ) {
                call_expr = this.parse_call_expr({
                    kind: "MemberExpr",
                    object: call_expr,
                    property: member,
                    computed: false
                });
            }
            else {
                return {
                    kind: "MemberExpr",
                    object: call_expr,
                    property: member,
                    computed: false
                };
            }
        }
        return call_expr;
    };
    Parser.prototype.parse_args = function () {
        this.expect(lexer_1.TokenType.OpenParen, "(");
        var args = this.at().type == lexer_1.TokenType.CloseParen ? [[], {}] : this.parse_arguments_list();
        this.expect(lexer_1.TokenType.CloseParen, "Missing closing parenthesis after arguments list");
        return args;
    };
    Parser.prototype.parse_arguments_list = function () {
        var args = [];
        var kwargs = {};
        do {
            if (this.tokens[1].value == "=") {
                var key = this.expect(lexer_1.TokenType.Identifier, "identifier", "for keyword argument");
                this.eat();
                var value = this.parse_expr();
                kwargs[key.value] = value;
            }
            else {
                args.push(this.parse_expr());
            }
        } while (this.at().type == lexer_1.TokenType.Comma && this.eat());
        return [args, kwargs];
    };
    Parser.prototype.parse_declaration_args = function () {
        this.expect(lexer_1.TokenType.OpenParen, "(");
        var args = this.at().type == lexer_1.TokenType.CloseParen
            ? []
            : this.parse_declaration_arguments_list();
        this.expect(lexer_1.TokenType.CloseParen, ")", "after arguments list");
        return args;
    };
    Parser.prototype.parse_declaration_arguments_list = function () {
        var args = [this.parse_declaration_argument()];
        while (this.at().type == lexer_1.TokenType.Comma && this.eat()) {
            args.push(this.parse_declaration_argument());
        }
        return args;
    };
    Parser.prototype.parse_declaration_argument = function () {
        var identifier = this.expect(lexer_1.TokenType.Identifier, "identifier", "in function declaration arguments").value;
        var value;
        if (this.at().type == lexer_1.TokenType.Equals && this.eat()) {
            value = this.parse_expr();
        }
        return {
            kind: "FuncDeclarationArgument",
            identifier: identifier,
            value: value
        };
        ;
    };
    Parser.prototype.parse_member_expr = function () {
        var object = this.parse_unary_operator();
        while (this.at().type == lexer_1.TokenType.Dot || this.at().type == lexer_1.TokenType.OpenBracket) {
            var operator = this.eat();
            var property = void 0;
            var computed = void 0;
            // non-computed values aka obj.expr
            if (operator.type == lexer_1.TokenType.Dot) {
                computed = false;
                // get identifier
                property = this.parse_unary_operator();
                if (property.kind != "Identifier") {
                    throw "Cannot use dot operator without right hand side being a identifier";
                }
            }
            else { // this allows obj[computedValue]
                computed = true;
                property = this.parse_expr();
                this.expect(lexer_1.TokenType.CloseBracket, "]", "in computed value");
            }
            object = {
                kind: "MemberExpr",
                object: object,
                property: property,
                computed: computed
            };
        }
        return object;
    };
    Parser.prototype.parse_unary_operator = function () {
        // skip to parse_expr
        switch (this.at().value) {
            case "!":
                return {
                    kind: "UnaryExpr",
                    operator: this.eat().value,
                    expr: this.parse_expr()
                };
            default:
                return this.parse_primary_expr();
        }
    };
    // Orders Of Prescidence
    // Assignment
    // Object
    // AdditiveExpr
    // MultiplicitaveExpr
    // Call
    // Member
    // PrimaryExpr
    // Parse Literal Values & Grouping Expressions
    Parser.prototype.parse_primary_expr = function () {
        var tk = this.at().type;
        // Determine which token we are currently at and return literal value
        switch (tk) {
            // User defined values.
            case lexer_1.TokenType.Identifier:
                return { kind: "Identifier", symbol: this.eat().value };
            // Constants and Numeric Constants
            case lexer_1.TokenType.Number:
                return {
                    kind: "NumericLiteral",
                    value: parseFloat(this.eat().value)
                };
            case lexer_1.TokenType.String:
                return {
                    kind: "StringLiteral",
                    value: this.eat().value
                };
            // Grouping Expressions
            case lexer_1.TokenType.OpenParen: {
                this.eat(); // eat the opening paren
                var value = this.parse_expr();
                this.expect(lexer_1.TokenType.CloseParen, "Unexpected token found inside parenthesised expression. Expected closing parenthesis."); // closing paren
                return value;
            }
            case lexer_1.TokenType.OpenBracket: {
                this.eat(); // eat the opening paren
                var value = this.parse_expr();
                this.expect(lexer_1.TokenType.CloseBracket, "]", "inside list declaration"); // closing paren
                return value;
            }
            // Unidentified Tokens and Invalid Code Reached
            default:
                console.error(this.at());
                throw "Unexpected token found during parsing!";
        }
    };
    return Parser;
}());
exports["default"] = Parser;
